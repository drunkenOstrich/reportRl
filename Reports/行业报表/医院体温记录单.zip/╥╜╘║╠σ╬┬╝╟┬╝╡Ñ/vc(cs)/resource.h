//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CustomDraw.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_GRPRINTVIEWER1              1004
#define IDC_PRINT                       1008
#define IDC_PREVIEW                     1009
#define IDC_REFRESH                     1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
