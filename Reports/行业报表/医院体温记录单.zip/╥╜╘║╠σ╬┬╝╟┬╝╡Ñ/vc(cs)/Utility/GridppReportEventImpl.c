
/////////////////////////////////////////////////////////////////////////////
// CGridppReportEventImpl
_ATL_FUNC_INFO CGridppReportEventImpl::OnBeforeSortInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_BSTR }};
//_ATL_FUNC_INFO CGridppReportEventImpl::OnFetchRecordInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_BYREF|VT_BOOL }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnFieldGetDisplayTextInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnTextBoxGetDisplayTextInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnSectionFormatInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
//_ATL_FUNC_INFO CGridppReportEventImpl::OnControlCustomDrawInfo = {CC_STDCALL, VT_EMPTY, 6, { VT_UNKNOWN, VT_UNKNOWN, VT_I4, VT_I4, VT_I4, VT_I4 }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnControlCustomDrawInfo = {CC_STDCALL, VT_EMPTY, 2, { VT_UNKNOWN, VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnGroupBeginInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnGroupEndInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnPrintPageInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_I4 }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnExportBeginInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnExportEndInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnShowPreviewWndInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN }};
_ATL_FUNC_INFO CGridppReportEventImpl::OnHyperlinkClickInfo = {CC_STDCALL, VT_EMPTY, 1, { VT_UNKNOWN, VT_BSTR, VT_BOOL}};
