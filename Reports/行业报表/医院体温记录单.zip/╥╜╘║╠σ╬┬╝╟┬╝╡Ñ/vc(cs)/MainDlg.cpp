// DlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include <string>
#include <atlcur.h>
#include "Project.h"
#include "MainDlg.h"
#include "Utility\GridppReportEventImpl.c"
#include "Utility\GetPath.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma warning( disable : 4244 )

/////////////////////////////////////////////////////////////////////////////
// CReportEvent
inline COLORREF ColorFromRGB(int r,int g, int b)
{
	return RGB(r, g, b);
}
class CReportEvent :public CGridppReportEventImpl
{
public:
	virtual void Initialize(void)
	{
		TCHAR FileName[MAX_PATH];
		GetModuleFileName(NULL, FileName, MAX_PATH);
		::CharLower( FileName );
		CString strFileName( FileName );
		int Index = strFileName.Find( _T("vc(cs)") );
		CString Path = strFileName.Mid(0, Index) + _T("vc(cs)\\");

		Report->LoadFromFile((LPCTSTR)(Path + L"ҽԺ���¼�¼��.grf"));
		Report->LoadDataFromURL((LPCTSTR)(Path + L"ҽԺ���¼�¼��.txt"));

		m_DrawControl = Report->ControlByName("sbTiWenDan");
	}

	virtual void ControlCustomDraw(IGRControl* Sender, IGRGraphics *Graphics)
	{
		double Left = Graphics->Left;
		double Top = Graphics->Top;
		double Width = Graphics->Width;
		double Height = Graphics->Height;

		double Bottom = Top + Height;
		double Right = Left + Width;
		
		double Days = Report->ParameterByName("Days")->AsInteger;     //����
		int BeginDate = Report->ParameterByName("BeginDate")->AsInteger; //��ʼ����
		int BeginHour = Report->ParameterByName("BeginHour")->AsInteger; //��ʼСʱ
		
		int HourSpan = 4; //ÿ��֮��Сʱ���
		double MaxTemp = 42; //����¶�
		double MinTemp = 34; //��С�¶�
		int TempScale = 5;   //1�ȵĿ̶��� 
		int HourScale = 24 / HourSpan; //ÿ���Сʱ�̶���
		double RowHeight = 20; //Ĭ�ϵ��и߶ȣ��ײ������еĸ߶�
		
		double MeiBoColWidth = 40; //�����еĿ���
		double TempColWidth = 75;  //�¶��еĿ���
		double OutColWidth = 20;   //�����еĿ���
		double BottomRows = 11;   //�²�����������������������
		double TitleRowHeight = RowHeight + 10; //��ͷ(������������Сʱ����)�и�
		double FuxiRowHeight = RowHeight + 10;  //�����еĸ߶�
		
		double GridCols = Days * (24 / HourSpan);            //��������
		double GridRows = (MaxTemp - MinTemp) * TempScale + 3; //����������������3��
		double TitleTop = Top + RowHeight;                    //����(��������)���ϲ�λ��
		double FuxiBottom = Top + (Height - BottomRows*RowHeight); //�����еĵײ�λ��
		double GridLeft = Left + MeiBoColWidth + TempColWidth; //�������λ��
		double GridRight = Left + Width;                       //�����ұ�λ��
		double GridTop = TitleTop + TitleRowHeight;         //���񶥱�λ��      
		double GridBottom = FuxiBottom - FuxiRowHeight;     //����ױ�λ��      
		double GridWidth = GridRight - GridLeft;            //����Ŀ���    
		double GridHeight = GridBottom - GridTop;           //����ĸ߶�        
		double GridRowHeight = GridHeight / GridRows;       //������п���    
		double GridColWidth = GridWidth / GridCols;         //������п���   
		
		double SquareSize = 6;  //���ݵ������������߳�

		int i;
		int j;
		double x, y, w, h; //λ����������ϣ������߱���
		double x2; 
		double w2;
		double xPrior;
		double yPrior;
		int ColNo;
		double val;
		std::wstring OutText;

		//IGRTextFormatPtr pTextFormat = Report->Utility->CreateTextFormat();
		//ע�⣺һ��Ҫ����Clone��������Ȼ��Ӱ�쵽�������������ָ�ʽ����
		IGRTextFormatPtr pTextFormat = Sender->AsTextBox->TextFormat->Clone(); 
		IGRTextFormatPtr pTextFormat2 = pTextFormat->Clone();

		IGRRecordsetPtr Recordset = Report->DetailGrid->Recordset;
		IGRFieldPtr riqi = Report->FieldByName("riqi");
		IGRFieldPtr times = Report->FieldByName("times");
		IGRFieldPtr tiwen = Report->FieldByName("tiwen");
		IGRFieldPtr maibo = Report->FieldByName("maibo");
		IGRFieldPtr fuxi = Report->FieldByName("fuxi");
		IGRFieldPtr beizhu = Report->FieldByName("beizhu");
		IGRFieldPtr tszl = Report->FieldByName("tszl");
		IGRFieldPtr dbcs = Report->FieldByName("dbcs");
		IGRFieldPtr cll = Report->FieldByName("cll");
		IGRFieldPtr ctl = Report->FieldByName("ctl");
		IGRFieldPtr cyll = Report->FieldByName("cyll");
		IGRFieldPtr cotl = Report->FieldByName("cotl");
		IGRFieldPtr czl = Report->FieldByName("czl");
		IGRFieldPtr rl = Report->FieldByName("rl");
		IGRFieldPtr xueya = Report->FieldByName("xueya");
		IGRFieldPtr tizhong = Report->FieldByName("tizhong");
		IGRFieldPtr ssts = Report->FieldByName("ssts");

		IGRParameterPtr BeginDateParam = Report->ParameterByName("BeginDate");
		IGRParameterPtr TempDateParam = Report->ParameterByName("TempDate");
		IGRParameterPtr TempHourParam = Report->ParameterByName("TempHour");
		IGRParameterPtr TempFloatParam = Report->ParameterByName("TempFloat");

		//{{�������ɫ��//////////////////////////////////////////////////
		Graphics->SelectPen(0.5, ColorFromRGB(0, 0, 0), (GRPenStyle)0); //grpsSolid
		
		//���Ȼ�����ͷ����
		Graphics->MoveTo(Left, TitleTop);
		Graphics->LineTo(GridRight, TitleTop);
		Graphics->MoveTo(Left, GridTop);
		Graphics->LineTo(GridRight, GridTop);
		
		//<<���ײ�������
		//�����������µ�����
		y = GridBottom;
		Graphics->MoveTo(Left, y);
		Graphics->LineTo(GridRight, y);
		
		y = FuxiBottom;
		for (i=0; i<BottomRows; ++i)
		{
		    x = Left;
		    if (i>=3 && i<8)
		      x += OutColWidth;
		    Graphics->MoveTo(x, y);
		    Graphics->LineTo(GridRight, y);
		    y += RowHeight;
		}
		
		//��"����"�е�����,��֣���������˳��쳣
		x = Left + OutColWidth;
		Graphics->MoveTo(x, FuxiBottom + RowHeight*2);
		Graphics->LineTo(x, FuxiBottom + RowHeight*8);
		//>>���ײ�������
		
		//��ǰ2�е�����
		x = Left + MeiBoColWidth;
		Graphics->MoveTo(x, TitleTop);
		Graphics->LineTo(x, GridBottom);
		x += TempColWidth;
		Graphics->MoveTo(x, Top);
		Graphics->LineTo(x, Bottom);
		
		Graphics->RestorePen();
		//}}�������ɫ��//////////////////////////////////////////////////
		
		//{{��Grid���߶�//////////////////////////////////////////////////
		Graphics->SelectPen(0.5, ColorFromRGB(0, 0, 0), (GRPenStyle)0); //grpsSolid
		
		//��ϸ����
		y = GridTop + GridRowHeight;
		for (i=1; i<GridRows; ++i)
		{
		    if ((i+2)%TempScale != 0)
		    {
		        Graphics->MoveTo(GridLeft, y);
		        Graphics->LineTo(GridRight, y);
		    }
		    y += GridRowHeight;
		}
		
		//��ϸ����
		x = GridLeft + GridColWidth;
		for (i=1; i<GridCols; ++i)
		{
		    if (i%HourScale != 0)
		    {
		        Graphics->MoveTo(x, TitleTop);
		        Graphics->LineTo(x, FuxiBottom);
		    }
		    x += GridColWidth;
		}
		
		Graphics->RestorePen();
		
		//���ֺ���
		Graphics->SelectPen(1.5, ColorFromRGB(0, 0, 0), (GRPenStyle)0);
		y = GridTop + GridRowHeight*3;
		for (i=3; i<GridRows; i+=TempScale)
		{
		    Graphics->MoveTo(GridLeft, y);
		    Graphics->LineTo(GridRight, y);
		    y += GridRowHeight*TempScale;
		}
		Graphics->RestorePen();
		
		//��������
		Graphics->SelectPen(1.5, ColorFromRGB(255, 0, 0), (GRPenStyle)0);
		x = GridLeft + GridColWidth*HourScale;
		for (i=HourScale; i<GridCols; i+=HourScale)
		{
		    Graphics->MoveTo(x, Top);
		    Graphics->LineTo(x, Bottom);
		    x += GridColWidth*HourScale;
		}
		Graphics->RestorePen();
		//}}��Grid���߶�//////////////////////////////////////////////////
		
		//{{�����̬����//////////////////////////////////////////////////
		//<<��һ��,��������
		x = Left;
		y = Top;
		w = GridLeft;
		h = RowHeight;
		Graphics->DrawText("��  ��", x, y, w, h, (GRTextAlign)34, false);
		
		TempDateParam->AsDateTime = BeginDateParam->AsDateTime;
		std::wstring year = L"";
		std::wstring month = L"";
		x = GridLeft;
		w = GridColWidth * HourScale;
		for (i=0; i<Days; ++i)
		{
		    std::wstring DateText = TempDateParam->DisplayText;
			std::wstring cur_year = DateText.substr(0, 4);
		    std::wstring cur_month = DateText.substr(4, 2);
		    std::wstring cur_day = DateText.substr(6);
		    DateText = L"";
		    if (year != cur_year)
		    {
		        year = cur_year;
		        DateText = year + L".";
		    }
		    if (month != cur_month)
		    {
		        month = cur_month;
		        DateText += month + L".";
		    }
		    DateText += cur_day;
		    
			Graphics->DrawText(DateText.c_str(), x, y, w, h, (GRTextAlign)34, false);

		    x += w;
			TempDateParam->AsDateTime += 1;
		}
		//>>��һ��,��������

		//<<�ڶ���,�����������£�Сʱ��
		x = Left;
		y = TitleTop;
		w = MeiBoColWidth;
		h = TitleRowHeight;
		Graphics->DrawText("����", x, y, w, h, (GRTextAlign)34, false);

		x = Left + MeiBoColWidth;
		w = TempColWidth;
		Graphics->DrawText("��  ��", x, y, w, h, (GRTextAlign)34, false);

		//Сʱ,������Ҫ��С����
		//ע�⣺һ��Ҫ����Clone��������Ȼ��Ӱ�쵽�������������嶨��
		IGRFontPtr Font = Sender->Font->Clone();
		Font->Point = Font->Point * 3 / 4;
		Graphics->SelectFont( Font );
		w = GridColWidth;
		for (i=0; i<Days; ++i)
		{
			x = GridLeft + GridColWidth*i*HourScale;
			TempHourParam->AsInteger = BeginHour;
			for (j=0; j<HourScale; ++j)
			{
				std::wstring HourText = TempHourParam->DisplayText;
				Graphics->DrawText(HourText.c_str(), x, y, w, h, (GRTextAlign)34, false);
				x += GridColWidth;
				TempHourParam->AsInteger += HourSpan;
			}
		}
		Graphics->RestoreFont();
		//>>�ڶ���,�����������£�Сʱ��

		//<<����������: ���������еĶ�������
		//Font->put_Size( CComCurrency((LONG)75000) );  //67500�ȽϺ���
		Font->Point = 7.5;
		Graphics->SelectFont( Font );
		Graphics->SelectTextColor( ColorFromRGB(255, 0 ,0) );
		x = Left;
		w = MeiBoColWidth;
		h = GridRowHeight*2;
		y = GridTop + GridRowHeight*2;
		TempHourParam->AsInteger = 180;
		for (i=0; i<=MaxTemp-MinTemp; ++i)
		{
			std::wstring HourText = TempHourParam->DisplayText;
			Graphics->DrawText(HourText.c_str(), x, y, w, h, (GRTextAlign)34, false);
			y += GridRowHeight*TempScale;
			if (i+1 == MaxTemp-MinTemp)
				y -= GridRowHeight;
			TempHourParam->AsInteger -= 20;
		}
		Graphics->RestoreTextColor();
		Graphics->RestoreFont();
		//>>����������: ���������еĶ�������

		//<<����������: �������µĶ�������
		x = Left + MeiBoColWidth;
		w = TempColWidth*3/5;
		h = GridRowHeight*2;
		y = GridTop;
		x2 = x + w; 
		w2 = TempColWidth - w;
		Graphics->DrawText("F", x, y, w, h, (GRTextAlign)34, false);
		Graphics->DrawText("C", x2, y, w2, h, (GRTextAlign)34, false);

		y += h;
		for (i=MaxTemp; i>=MinTemp; --i)
		{
			TempFloatParam->AsFloat = double(i)*1.8 + 32; 	// �� �� 1.8 + 32
			std::wstring TempText = TempFloatParam->DisplayText;
			Graphics->DrawText(TempText.c_str(), x, y, w, h, (GRTextAlign)34, false);

			TempFloatParam->AsFloat = i;
			TempText = TempFloatParam->DisplayText;
			Graphics->DrawText(TempText.c_str(), x2, y, w2, h, (GRTextAlign)34, false);

			y += GridRowHeight*TempScale;
			if (i-1 == MinTemp)
				y -= GridRowHeight;
		}
		//>>����������: �������µĶ�������
		//}}�����̬����//////////////////////////////////////////////////

		//{{�����̬����//////////////////
		//��������ǰ������
		x = Left;
		y = GridBottom;
		w = MeiBoColWidth + TempColWidth;
		h = FuxiRowHeight;
		Graphics->DrawText("����(��/��)", x, y, w, h, (GRTextAlign)34, false);

		//������������뱸ע����
		Font->Point = 6.75; //Font->put_Size( CComCurrency((LONG)67500) );  //67500�ȽϺ���
		Graphics->SelectFont( Font );
		w = GridColWidth;
		h = FuxiRowHeight / 2;
		y = GridBottom;
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			int No = (riqi->AsInteger - BeginDate)*HourScale + times->AsInteger - 1;
			x = GridLeft + GridColWidth*No;

			//������������
			if (fuxi->AsInteger > 0)
			{
				TempHourParam->AsInteger = fuxi->AsInteger;
				y = GridBottom;
				if (No%2 != 0)
					y += h;
				OutText = TempHourParam->DisplayText;
				Graphics->DrawText(OutText.c_str(), x+1, y, w, h, (GRTextAlign)34, false);
			}

			//�����ע��������
			if ( !beizhu->IsNull ) //(OutText != "")
			{
				OutText = beizhu->AsString;
				y = GridTop + 3*GridRowHeight + 2;
				pTextFormat->TextOrientation = grtoU2DL2R0;
				pTextFormat->TextAlign = grtaTopCenter;
				Graphics->DrawFormatText(OutText.c_str(), x+1, y, w, GridHeight, pTextFormat);
			}

			Recordset->Next();
		}
		Graphics->RestoreFont();


		//<<�������ͼ��
		Graphics->SelectPen(1, ColorFromRGB(255, 0, 0), (GRPenStyle)0); //��ɫ��

		//����
		xPrior = 0;
		yPrior = 0;
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			val = maibo->AsFloat;
			if (val > 0)
			{
				ColNo = (riqi->AsInteger - BeginDate)*HourScale + times->AsInteger - 1;
				x = GridLeft + GridColWidth*ColNo + GridColWidth/2;
				y = GridTop + ((180.0 - val)*TempScale/20 + 3) * GridRowHeight;

				if (xPrior > 0)
				{
					Graphics->MoveTo(xPrior, yPrior);
					Graphics->LineTo(x, y);
				}
				xPrior = x;
				yPrior = y;
			}

			Recordset->Next();
		}

		//���ݵ�ͼ��
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			val = maibo->AsFloat;
			if (val > 0)
			{
				ColNo = (riqi->AsInteger - BeginDate)*HourScale + times->AsInteger - 1;
				x = GridLeft + GridColWidth*ColNo + GridColWidth/2;
				y = GridTop + ((180.0 - val)*TempScale/20 + 3) * GridRowHeight;

				Graphics->Ellipse(x-SquareSize/2, y-SquareSize/2, SquareSize, SquareSize, true);
			}

			Recordset->Next();
		}

		Graphics->RestorePen();
		//>>�������ͼ��

		//<<�������ͼ��
		Graphics->SelectPen(1, ColorFromRGB(0, 0, 255), (GRPenStyle)0); //

	    //����
		xPrior = 0;
		yPrior = 0;
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			val = tiwen->AsFloat;
			if (val > 0)
			{
				ColNo = (riqi->AsInteger - BeginDate)*HourScale + times->AsInteger - 1;
				x = GridLeft + GridColWidth*ColNo + GridColWidth/2; //SquareOffsetX;
				y = GridTop + ((MaxTemp - val)*TempScale + 3) * GridRowHeight; //+ SquareOffsetY;

				if (xPrior > 0)
				{
					Graphics->MoveTo(xPrior, yPrior);
					Graphics->LineTo(x, y);
				}
				xPrior = x;
				yPrior = y;
			}

			Recordset->Next();
		}

		//���ݵ�ͼ��
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			val = tiwen->AsFloat;
			if (val > 0)
			{
				ColNo = (riqi->AsInteger - BeginDate)*HourScale + times->AsInteger - 1;
				x = GridLeft + GridColWidth*ColNo + GridColWidth/2; //SquareOffsetX;
				y = GridTop + ((MaxTemp - val)*TempScale + 3) * GridRowHeight; //+ SquareOffsetY;

				x -= SquareSize/2; 
				y -= SquareSize/2; 
				Graphics->FillRect(x-1, y-1, SquareSize+2, SquareSize+2, RGB(255, 255, 255));
				Graphics->MoveTo(x, y);
				Graphics->LineTo(x+SquareSize, y+SquareSize);
				Graphics->MoveTo(x+SquareSize, y);
				Graphics->LineTo(x, y+SquareSize);
			}

			Recordset->Next();
		}

		Graphics->RestorePen();
		//>>�������ͼ��

		//����ײ��е�����
		x = Left;
		y = FuxiBottom;
		w = MeiBoColWidth + TempColWidth;
		h = RowHeight;
		x2 = x + OutColWidth;
		w2 = w - OutColWidth;
		Graphics->DrawFormatText("�� �� �� ��", x, y + RowHeight*0, w, h, pTextFormat2);
		Graphics->DrawFormatText("�� �� �� ��", x, y + RowHeight*1, w, h, pTextFormat2);
		Graphics->DrawFormatText("�� ��(����)", x2, y + RowHeight*2, w2, h, pTextFormat2);
		Graphics->DrawFormatText("̵ ��(����)", x2, y + RowHeight*3, w2, h, pTextFormat2);
		Graphics->DrawFormatText("������(����)", x2, y + RowHeight*4, w2, h, pTextFormat2);
		Graphics->DrawFormatText("Ż����(����)", x2, y + RowHeight*5, w2, h, pTextFormat2);
		Graphics->DrawFormatText("�� ��(����)", x2, y + RowHeight*6, w2, h, pTextFormat2);
		Graphics->DrawFormatText("�� ��(����)", x, y + RowHeight*7, w, h, pTextFormat2);
		Graphics->DrawFormatText("Ѫѹ(mmHg)", x, y + RowHeight*8, w, h, pTextFormat2);
		Graphics->DrawFormatText("�� ��(Kg)", x, y + RowHeight*9, w, h, pTextFormat2);
		Graphics->DrawFormatTextShrinkToFit("����������(������С��ʾ)", x, y + RowHeight*10, w, h, pTextFormat2); //����Ŀ����ʾ�� DrawFormatTextShrinkToFit �������÷�

		x = Left;
		y = FuxiBottom + RowHeight*2;
		w = OutColWidth;
		h = RowHeight*5;
		pTextFormat->TextOrientation = grtoU2DL2R0;
		pTextFormat->TextAlign = grtaTopCenter;
		Graphics->DrawFormatText("��    ��", x, y+20, w, GridHeight, pTextFormat);


		//�������ͼ��
		Recordset->First();
		while ( !Recordset->Eof() )
		{
			//���ݼ��趼�Ǽ�¼��ÿ��ĵ�һ��������
			if (times->AsInteger == 1)
			{
				x = GridLeft + GridColWidth * (riqi->AsInteger - BeginDate)*HourScale;
				y = FuxiBottom;
				w = GridColWidth * HourScale;
				h = RowHeight;
				if ( !tszl->IsNull )
					Graphics->DrawFormatText(tszl->AsString, x, y + RowHeight*0, w, h, pTextFormat2);
				if ( !dbcs->IsNull )
					Graphics->DrawFormatText(dbcs->AsString, x, y + RowHeight*1, w, h, pTextFormat2);
				if ( !cll->IsNull )
					Graphics->DrawFormatText(cll->AsString, x, y + RowHeight*2, w, h, pTextFormat2);
				if ( !ctl->IsNull )
					Graphics->DrawFormatText(ctl->AsString, x, y + RowHeight*3, w, h, pTextFormat2);
				if ( !cyll->IsNull )
					Graphics->DrawFormatText(cyll->AsString, x, y + RowHeight*4, w, h, pTextFormat2);
				if ( !cotl->IsNull )
					Graphics->DrawFormatText(cotl->AsString, x, y + RowHeight*5, w, h, pTextFormat2);
				if ( !czl->IsNull )
					Graphics->DrawFormatText(czl->AsString, x, y + RowHeight*6, w, h, pTextFormat2);
				if ( !rl->IsNull )
					Graphics->DrawFormatText(rl->AsString, x, y + RowHeight*7, w, h, pTextFormat2);
				if ( !xueya->IsNull )
					Graphics->DrawFormatText(xueya->AsString, x, y + RowHeight*8, w, h, pTextFormat2);
				if ( !tizhong->IsNull )
					Graphics->DrawFormatText(tizhong->AsString, x, y + RowHeight*9, w, h, pTextFormat2);
				if ( !ssts->IsNull )
					Graphics->DrawFormatText(ssts->AsString, x, y + RowHeight*10, w, h, pTextFormat2);
			}

			Recordset->Next();
		}
		//}}�����̬����//////////////////
	}

    IGRControlPtr m_DrawControl;
	IGridppReportPtr Report;
};

/////////////////////////////////////////////////////////////////////////////
// CMainDlg dialog

CMainDlg::CMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	//{{AFX_MSG_MAP(CMainDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_PRINT, OnPrint)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainDlg message handlers

BOOL CMainDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//��������������
	m_pGridppReport.CreateInstance( __uuidof(GridppReport) );
	ATLASSERT(m_pGridppReport != NULL);

	//ȡ�ò�ѯ��ʾ���ؼ��Ľӿ�ָ��
	CWnd *pDispalyViewerWnd = GetDlgItem(IDC_GRPRINTVIEWER1);
	LPUNKNOWN spUnk = pDispalyViewerWnd->GetControlUnknown();
	spUnk->QueryInterface(__uuidof(IGRPrintViewer), (void**)(&m_pPrintViewer));
	ATLASSERT(m_pPrintViewer != NULL);

	//���ļ������뱨��ģ�����ݵ�����������
	//CString FileName = _T("d:\\cd\\customdraw.grf");
	//m_pGridppReport->LoadFromFile( (LPCTSTR)FileName );

	//�����¼���Ӧ����
	CComObject<CReportEvent> *pEvent;
	CComObject<CReportEvent>::CreateInstance( &pEvent );
	m_pReportEvents = pEvent;
	m_pReportEvents->AddRef();
	pEvent->Report = m_pGridppReport;
	HRESULT hr = m_pReportEvents->DispEventAdvise(m_pGridppReport, &__uuidof(_IGridppReportEvents)) ;
	hr;
	ATLASSERT( SUCCEEDED(hr) );

	//��ѯ��ʾ���ؼ���������������
	m_pPrintViewer->Report = m_pGridppReport;

	//������ѯ��ʾ��������
	m_pPrintViewer->Start();

	AdjustViewerSize();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMainDlg::AdjustViewerSize(void)
{
	CWnd *pDispalyViewerWnd = GetDlgItem(IDC_GRPRINTVIEWER1);
	if ( pDispalyViewerWnd )
	{
		RECT ClientRect;
		GetClientRect( &ClientRect );
		ClientRect.top += 40;
		pDispalyViewerWnd->MoveWindow(&ClientRect, FALSE);
	}
}

void CMainDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	CDialog::OnSysCommand(nID, lParam);
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMainDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int Left = (rect.Width() - cxIcon + 1) / 2;
		int Top = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(Left, Top, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMainDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMainDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	AdjustViewerSize();	
}

void CMainDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	if (m_pReportEvents != NULL)	
	{	
		HRESULT hr = m_pReportEvents->DispEventUnadvise(m_pGridppReport, &__uuidof(_IGridppReportEvents));
		m_pReportEvents->Release();
		m_pReportEvents = NULL;
		hr;
		ATLASSERT( SUCCEEDED(hr) );
	}
	m_pPrintViewer.Release();
	m_pGridppReport.Release();
}

void CMainDlg::OnPrint() 
{
    m_pGridppReport->Print(TRUE);
}

void CMainDlg::OnPreview() 
{
	m_pGridppReport->PrintPreview(TRUE);
}

void CMainDlg::OnRefresh() 
{
	m_pPrintViewer->Refresh();
}